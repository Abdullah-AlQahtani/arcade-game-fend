# [Udacity Classic Arcade Game]

In this game you have a Player and Enemies (Bugs). The goal of the player is to reach the water, without colliding into any one of the enemies. The player can move left, right, up and down. The enemies move in varying speeds on the paved block portion of the scene. Once a the player collides with an enemy, the game is reset and the player moves back to the start square. Once the player reaches the water the game is won.


## How To Play

Use the arrow keys to move the character. Avoid hitting the bugs while trying to make it to the water on the other side of the stone. When you reach the water your character will move back to the grass and increase your score so that you can try again.
